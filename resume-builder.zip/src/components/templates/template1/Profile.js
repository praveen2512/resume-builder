import React from 'react';
import {BusinessCenterRounded, LibraryBooksRounded, SchoolRounded, WorkRounded} from '@material-ui/icons';
import { Grid } from '@material-ui/core';
import {Employment} from './Employment';
import { Education } from './Education';
import {profile} from '../../../data/data';

export const Profile = () => {

    const {education, employmentHistory, expriences, professionalSummary} = profile;

    return (
        <Grid item sm={8}>
          <div className="prof-summary">
            <div className="section-header">
              <BusinessCenterRounded className="custom-icon" fontSize="medium"/>
              <h3>Professional Summary</h3>
            </div>
            <ul className="custom-list">
              {
                professionalSummary.map((x, idx) => <li key={idx}><p>{x}</p></li>)
              }
            </ul>
          </div>

          <div className="emp-history mt-4">
            <div className="section-header">
              <WorkRounded className="custom-icon" fontSize="medium"/>
              <h3>Employment History</h3>
            </div>

            {
                employmentHistory.map((x, idx) => <Employment key={idx} data={x} />)
            }
            
          </div>

          <div className="experience mt-4">
            <div className="section-header">
              <LibraryBooksRounded className="custom-icon" fontSize="medium"/>
              <h3>Experiences</h3>
            </div>
            <ul className="custom-list">
              {
                expriences.map((x, idx)=><li key={idx}><p>{x}</p></li>)
              }
            </ul>
          </div>
          
          <div className="education mt-4">
            <div className="section-header">
              <SchoolRounded className="custom-icon" fontSize="medium"/>
              <h3>Education</h3>
            </div>
            {
              education.map(((x, idx)=><Education key={idx} data={x}/>))
            }
          </div>
          
        </Grid>
    )
}
